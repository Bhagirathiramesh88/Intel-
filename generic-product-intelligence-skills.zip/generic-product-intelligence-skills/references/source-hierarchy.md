# Source Hierarchy

## Tier 1 — authoritative records

- Regulators and government agencies
- Courts, patent offices, legislatures, and procurement authorities
- Clinical, technical, standards, and safety registries
- Audited filings and legally required disclosures
- Official recall, shortage, incident, or enforcement databases

## Tier 2 — direct primary sources

- Company press releases and investor-relations pages
- Product documentation, pricing pages, status pages, and release notes
- Official trial announcements and conference presentations containing new data
- Partner, customer, distributor, or payer announcements

## Tier 3 — independent secondary sources

- Reputable trade publications
- Major news organizations
- Peer-reviewed journals
- Recognized industry analysts with transparent sourcing

## Tier 4 — discovery-only leads

- Aggregators and syndication sites
- Search-result snippets
- Social posts
- Blogs without original evidence
- Forums and community posts

Tier 4 can generate a lead but cannot confirm an event.

## Evidence rules

1. Use the highest-tier accessible source.
2. For Board-level events, seek Tier 1 or Tier 2 plus independent corroboration when available.
3. Preserve exact titles, publishers, publication dates, and direct URLs.
4. Confirm event date separately from publication date.
5. Explicitly identify statements that originate only from the company.
6. Record inaccessible or conflicting evidence rather than resolving it by guesswork.
