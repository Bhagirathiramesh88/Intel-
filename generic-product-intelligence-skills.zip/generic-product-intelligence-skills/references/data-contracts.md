# Data Contracts

Use these structures when passing work between skills. JSON is shown for clarity; equivalent structured objects are acceptable.

## ProjectConfig

```json
{
  "company": "string",
  "product": "string",
  "aliases": ["string"],
  "industry": "string",
  "start_date": "YYYY-MM-DD",
  "end_date": "YYYY-MM-DD",
  "regions": ["string"],
  "known_competitors": ["string"],
  "partners": ["string"],
  "substitutes": ["string"],
  "customer_segments": ["string"],
  "authorities": ["string"],
  "priority_topics": ["string"],
  "materiality_overrides": ["string"]
}
```

## ResearchUniverse

```json
{
  "focal_entity": {},
  "marketed_competitors": [],
  "pipeline_competitors": [],
  "partners": [],
  "substitutes": [],
  "channels_and_access": [],
  "authorities_and_standards": [],
  "unknown_entrant_themes": [],
  "search_queries": []
}
```

## EventCandidate

```json
{
  "event_id": "stable-string",
  "headline": "string",
  "entities": ["string"],
  "event_type": "regulatory|product|technical|clinical|commercial|corporate|policy|safety|supply|other",
  "event_date": "YYYY-MM-DD|null",
  "discovery_date": "YYYY-MM-DD",
  "geography": ["string"],
  "claim": "string",
  "source_urls": ["https://..."],
  "suspected_duplicate_of": "event_id|null",
  "outside_window": false
}
```

## VerifiedEvent

```json
{
  "event_id": "string",
  "canonical_event": "string",
  "event_date": "YYYY-MM-DD",
  "publication_dates": ["YYYY-MM-DD"],
  "hard_facts": ["string"],
  "company_claims": ["string"],
  "independently_verified_facts": ["string"],
  "conflicts": ["string"],
  "confidence": "confirmed|corroborated|company-announced|unconfirmed",
  "primary_sources": [{"title": "string", "publisher": "string", "date": "YYYY-MM-DD", "url": "https://..."}],
  "secondary_sources": [],
  "in_reporting_window": true,
  "duplicate_ids": []
}
```

## TriagedEvent

```json
{
  "event_id": "string",
  "impact": 0,
  "immediacy": 0,
  "credibility": 0,
  "scale": 0,
  "novelty": 0,
  "total": 0,
  "route": "board|watch|exclude|unconfirmed",
  "materiality_reason": "string",
  "override_applied": false
}
```

## ImplicationAssessment

```json
{
  "event_id": "string",
  "share": "string|null",
  "access": "string|null",
  "positioning": "string|null",
  "economics": "string|null",
  "timing": "string|null",
  "direction": "positive|negative|mixed|neutral|uncertain",
  "recommended_action": "string|null",
  "owner": "string|null",
  "deadline_or_trigger": "string|null",
  "assumptions": ["string"]
}
```
