# Generic Product Intelligence Skill Set

A portable, industry-agnostic collection of composable Agent Skills for producing decision-grade competitive-intelligence snapshots about any product.

## Included skills

| Skill | Purpose |
|---|---|
| `product-intelligence-orchestrator` | Coordinates the end-to-end workflow and quality gate |
| `research-universe-builder` | Defines the market system and search entities |
| `market-event-discovery` | Finds in-period material event candidates |
| `evidence-verification` | Verifies dates, claims, sources, and confidence |
| `new-entrant-detection` | Detects companies and assets outside known competitor lists |
| `materiality-triage` | Scores and routes events to Board, Watch, or Exclude |
| `strategic-implication-analysis` | Converts verified events into product implications and actions |
| `executive-intelligence-brief` | Produces a concise C-suite report |

## Directory layout

```text
generic-product-intelligence-skills/
├── README.md
├── product-intelligence-orchestrator/SKILL.md
├── research-universe-builder/SKILL.md
├── market-event-discovery/SKILL.md
├── evidence-verification/SKILL.md
├── new-entrant-detection/SKILL.md
├── materiality-triage/SKILL.md
├── strategic-implication-analysis/SKILL.md
├── executive-intelligence-brief/SKILL.md
├── references/
│   ├── data-contracts.md
│   └── source-hierarchy.md
└── assets/
    ├── project-config.yaml
    └── executive-brief-template.md
```

## Installation

Copy the eight skill directories into a skills-compatible location. Common examples include:

```text
.agents/skills/
.claude/skills/
~/.agents/skills/
```

Keep `references/` and `assets/` accessible to the skills, or copy the referenced files into each skill's directory if the host requires self-contained skill folders.

## Quick start

1. Edit `assets/project-config.yaml`.
2. Invoke `product-intelligence-orchestrator`.
3. Provide the completed configuration.
4. Let the orchestrator call the narrower skills in order.
5. Require human review before distributing high-impact strategic conclusions.

Example request:

```text
Use the product-intelligence-orchestrator skill.
Create a market snapshot using assets/project-config.yaml.
Apply the date range strictly, search for unknown entrants, and return only material events.
```

## Design principles

- Industry-agnostic configuration
- Strict event-date enforcement
- Primary-source preference
- Explicit confidence states
- Separate evidence from interpretation
- Search beyond known competitors
- Action-oriented implications
- No filler when no material events exist

## Portability

Each skill uses the open `SKILL.md` structure with required `name` and `description` frontmatter. Tool names are described generically so the host agent can map them to its available search, browsing, registry, filing, coding, or document tools.
