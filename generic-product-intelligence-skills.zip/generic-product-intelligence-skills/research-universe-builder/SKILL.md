---
name: research-universe-builder
description: Builds an industry-agnostic research universe around a focal product, including direct competitors, pipeline products, partners, substitutes, channels, authorities, and entrant themes. Use before competitive research when scope is incomplete, biased toward known names, or needs systematic coverage.
license: MIT
compatibility: Works without external tools for planning; current market validation requires research access.
metadata:
  category: competitive-intelligence
  role: planning
---

# Research Universe Builder

## Objective

Define what must be searched before collecting events. Model the product as part of a competitive system rather than a fixed competitor list.

## Procedure

1. Normalize the focal product:
   - Company, brand, aliases, generic or technical names
   - Model, SKU, version, project, trial, or code names
   - Core job-to-be-done and customer segments
   - Regions and routes to market
2. Establish the baseline as of the day before the reporting period:
   - Commercial or development stage
   - Available versions and geographies
   - Current partners and channels
   - Known expected milestones
3. Map these groups:
   - Marketed direct competitors
   - Pipeline or prelaunch competitors
   - Partners with aligned, competing, or mixed incentives
   - Substitutes that solve the same job differently
   - Demand reducers that reduce the underlying need
   - Access, distribution, procurement, reimbursement, or platform gatekeepers
   - Regulators, standards bodies, professional societies, and policymakers
4. Generate unknown-entrant themes based on mechanism, enabling technology, customer problem, adjacent category, and business model.
5. Produce entity-specific and theme-specific search queries.

## Industry adaptation

Translate generic concepts to the target industry:

- Pharmaceuticals: indication, mechanism, route, trial, label, payer, guideline, safety
- Software: use case, feature, integration, security, pricing, platform, open source, release
- Devices: intended use, clearance, validation, recall, distributor, procurement, consumables
- Consumer: category, retailer, price, recall, distribution, private label, substitute behavior
- Industrial: specification, certification, tender, supplier, capacity, reliability, service network

Do not force irrelevant event classes onto the industry.

## Output

Return a `ResearchUniverse` matching `references/data-contracts.md`, plus:

- Important scope assumptions
- Search blind spots
- Baseline facts requiring `[BACKGROUND]`
- A coverage checklist grouped by entity and event class

## Quality checks

- The universe extends beyond names supplied by the user.
- Partners are analyzed for adverse as well as favorable moves.
- At least one substitute and one demand-reduction pathway were considered.
- Unknown-entrant queries do not depend on known company names.
- Every query includes relevant regional terminology or synonyms when needed.
