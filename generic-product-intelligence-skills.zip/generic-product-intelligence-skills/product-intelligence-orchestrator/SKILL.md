---
name: product-intelligence-orchestrator
description: Coordinates a complete, source-verified competitive-intelligence workflow for any product. Use when a user requests a market snapshot, competitor update, product-landscape review, board intelligence brief, or recurring market monitor spanning discovery, verification, materiality, implications, and reporting.
license: MIT
compatibility: Requires web or database research access for current-event work. Designed to compose with the other skills in this package.
metadata:
  category: competitive-intelligence
  role: orchestrator
---

# Product Intelligence Orchestrator

## Goal

Produce a concise decision-support brief about a focal product without confusing information collection with intelligence.

## Required inputs

Require `company`, `product`, `start_date`, `end_date`, and `regions`. Ask for missing fields only when they cannot be safely inferred. Accept optional aliases, industry, competitors, partners, substitutes, authorities, and priority topics.

## Workflow

1. Validate dates, scope, product identity, and geography.
2. Invoke `research-universe-builder` to establish the complete market system.
3. Invoke `market-event-discovery` for focal-product, competitor, partner, substitute, access, policy, safety, supply, corporate, and product events.
4. Invoke `new-entrant-detection` independently; do not seed it only with known competitors.
5. Send all candidates to `evidence-verification`.
6. Place unconfirmed items outside the main event set.
7. Send verified in-window events to `materiality-triage`.
8. Send Board and Watch events to `strategic-implication-analysis`.
9. Invoke `executive-intelligence-brief` with all structured outputs.
10. Run the final quality gate.

## State management

Maintain separate collections:

- `background`: baseline facts dated before the period
- `candidates`: raw discoveries
- `verified_events`: verified facts and company claims
- `unconfirmed`: unresolved leads
- `triaged_events`: Board, Watch, and Exclude
- `implications`: product-specific interpretations and actions
- `source_register`: canonical source metadata

Never allow interpretation to overwrite evidence.

## Stop conditions

Research is complete only when:

- All configured entities and event classes were searched
- Mechanism- and problem-based new-entrant searches were run
- Board-level claims have primary evidence or an explicit limitation
- Publication dates and event dates were checked
- Duplicate stories were consolidated
- Empty sections reflect a true lack of qualifying evidence

## Final quality gate

Reject or revise the output if any condition is true:

- An event falls outside the window without `[BACKGROUND]`
- A factual claim lacks a source
- A company claim is written as independently verified fact
- A repeated announcement is presented as a new event
- An implication is vague or disconnected from share, access, positioning, economics, or timing
- A partner is treated as automatically favorable
- Unconfirmed information appears in Board or Watch
- Empty sections contain filler

## Failure handling

If tools, paywalls, inaccessible records, or conflicting sources prevent confirmation, preserve the lead in `WHAT I COULD NOT CONFIRM`. Never fill evidence gaps with assumptions.
