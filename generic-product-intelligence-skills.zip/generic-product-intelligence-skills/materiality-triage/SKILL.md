---
name: materiality-triage
description: Scores verified product-market events for strategic materiality and routes them to Board-level, Watch, Exclude, or Unconfirmed. Use when research contains too many events and decision-makers need a consistent threshold based on impact, immediacy, credibility, scale, and novelty.
license: MIT
compatibility: No special tools required after verified event data is available.
metadata:
  category: competitive-intelligence
  role: triage
---

# Materiality Triage

## Preconditions

Accept only verified events. Send unconfirmed events directly to `unconfirmed` without scoring them into Board or Watch.

## Scoring model

Score each event:

- Impact `0–3`: expected effect on share, revenue, access, safety, differentiation, or strategic freedom
- Immediacy `0–2`: decision required now versus long-dated
- Credibility `0–2`: strength and independence of evidence
- Scale `0–2`: breadth across customers, regions, channels, or operations
- Novelty `0–1`: genuinely new event versus incremental update

Total range: `0–10`.

## Default routing

- `7–10`: Board-level
- `4–6`: Watch
- `0–3`: Exclude
- Unconfirmed evidence: Unconfirmed

## Overrides

Escalate regardless of score when a confirmed event involves:

- Severe safety, security, legal, or compliance exposure
- Binding regulator, court, standards, or policy action
- National access, formulary, channel, or procurement change
- Material recall, shortage, outage, or supply interruption
- Credible near-term launch that removes a core product advantage
- A user-defined materiality override

Document every override.

## Guardrails

- Do not inflate scores because an event generated extensive media coverage.
- Do not lower credibility merely because an authoritative event is unfavorable.
- Do not count article volume as novelty or scale.
- Score the underlying event once after deduplication.
- Use the focal product and specified geography as the frame of reference.

## Output

Return `TriagedEvent` objects matching `references/data-contracts.md`, sorted by route and total score. Include one sentence explaining the materiality mechanism.
