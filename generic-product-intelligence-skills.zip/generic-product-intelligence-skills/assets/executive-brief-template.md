**BOTTOM LINE** — {{Two or three sentences on what changed for the focal product.}}

**BOARD-LEVEL (act or decide now)**

- **Headline:**
- **Who:**
- **What happened:**
- **Evidence status:**
- **So what for {{PRODUCT}}:**
- **Recommended action:**
- **Source:** Publisher, exact title, publication date, direct URL

**WATCH (monitor, no action yet)**

- **Headline:**
- **Who:**
- **What happened:**
- **Evidence status:**
- **So what for {{PRODUCT}}:**
- **Trigger to escalate:**
- **Source:** Publisher, exact title, publication date, direct URL

**PARTNERS**

{{One subsection per configured partner.}}

**POSSIBLE NEW ENTRANTS**

- **Who they are:**
- **Asset/product and mechanism:**
- **Current stage and latest dated milestone:**
- **Evidence status:**
- **Threat credibility:** High / Medium / Low
- **Why:**
- **Source:** Publisher, exact title, publication date, direct URL

**WHAT I COULD NOT CONFIRM**

{{Describe the reference, missing evidence, and reason for exclusion—or write “Nothing.”}}
