---
name: evidence-verification
description: Verifies competitive-intelligence event candidates by tracing claims to primary sources, checking event and publication dates, resolving duplicates and conflicts, and assigning evidence confidence. Use before materiality scoring, strategic analysis, or executive reporting.
license: MIT
compatibility: Requires access to original webpages, filings, registries, or documents for robust verification.
metadata:
  category: competitive-intelligence
  role: verification
---

# Evidence Verification

## Objective

Convert raw discoveries into auditable events while preserving the distinction between fact, claim, interpretation, and uncertainty.

## Verification procedure

For each candidate:

1. Open the original source, not only a search snippet.
2. Identify the canonical underlying event.
3. Record event date and every cited publication date.
4. Confirm whether the event falls inside the reporting window.
5. Trace claims to the highest available source tier in `references/source-hierarchy.md`.
6. Extract hard facts exactly: amounts, endpoints, versions, geographies, dates, status, and decision language.
7. Separate:
   - Company-announced statements
   - Independently verified facts
   - Analyst or reporter interpretation
8. Seek independent corroboration for high-impact events when available.
9. Investigate conflicting figures, dates, stages, or descriptions.
10. Merge duplicate and syndicated items under one event ID.

## Confidence states

- `confirmed`: authoritative record, legally required filing, registry, court record, or directly observable launch
- `corroborated`: direct source plus credible independent confirmation
- `company-announced`: official company statement without independent confirmation
- `unconfirmed`: credible reference exists, but the necessary evidence is missing, inaccessible, or conflicting

Do not describe `company-announced` as independently verified. Route `unconfirmed` only to the uncertainty section.

## Date handling

- The event date governs period inclusion.
- A publication during the period that restates an older event is not new.
- If an event began before the period but materially changed during it, include only the dated change.
- Mark relevant pre-period facts `[BACKGROUND]`.

## Output

Return `VerifiedEvent` objects matching `references/data-contracts.md`, a duplicate map, and an unconfirmed-leads list stating what evidence is missing.

## Quality checks

- Every hard fact maps to a source.
- All URLs are direct and accessible when possible.
- Titles and publication dates are preserved.
- Conflicts are disclosed rather than silently resolved.
- No unsupported inference appears in `hard_facts`.
