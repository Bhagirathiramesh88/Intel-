---
name: new-entrant-detection
description: Detects previously unknown companies, products, assets, technologies, and business models entering a focal product market. Use when competitive research must look beyond named competitors through mechanism, problem, patent, registry, transaction, pilot, filing, and adjacent-market searches.
license: MIT
compatibility: Best results require web, patent, registry, filing, transaction, and news search access.
metadata:
  category: competitive-intelligence
  role: early-warning
---

# New Entrant Detection

## Objective

Find credible entrants before they appear in standard competitor trackers.

## Search without known names

Build searches around:

- Customer problem and job-to-be-done
- Product mechanism or delivery method
- Enabling technology or component
- Alternative business model
- Patent, trademark, standards, and certification activity
- Regulatory, clinical, technical, or safety registries
- Acquisition, in-licensing, distribution, manufacturing, and financing language
- Trial, pilot, beta, filing, waitlist, and launch language
- Adjacent companies moving into the category
- Phrases such as `alternative to {{PRODUCT}}`

Use synonyms, regional terminology, technical names, and broad category language.

## Candidate qualification

A candidate qualifies when evidence shows it is developing, acquiring, in-licensing, filing, piloting, or launching an offering that addresses the same customer need.

For each candidate assess:

- Asset or product and mechanism
- Current stage and latest dated milestone
- Technical or regulatory feasibility
- Funding and organizational capabilities
- Differentiation and intellectual-property position
- Route to market and partnerships
- Expected time to meaningful competition

## Threat credibility

- `high`: credible product, capabilities, evidence, route to market, and near- or medium-term milestone
- `medium`: plausible asset and team, but meaningful evidence, funding, timing, or commercialization gaps remain
- `low`: very early, poorly supported, technically doubtful, or lacking a credible route to market

Credibility is not the same as impact. State both when possible.

## Output

Return verified entrant candidates with source metadata, evidence status, threat credibility, rationale, missing information, and next observable milestone.

If none qualify, return `None detected this period.` Do not recycle known competitors or invent candidates.
