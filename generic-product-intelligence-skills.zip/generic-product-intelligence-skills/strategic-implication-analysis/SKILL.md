---
name: strategic-implication-analysis
description: Converts verified and triaged market events into concrete implications, actions, owners, and escalation triggers for a focal product. Use after evidence verification and materiality triage when leaders need to understand effects on share, access, positioning, economics, or timing.
license: MIT
compatibility: No special tools required, though internal commercial data improves specificity.
metadata:
  category: competitive-intelligence
  role: analysis
---

# Strategic Implication Analysis

## Objective

Explain why each material event matters to the focal product without overstating what the evidence proves.

## Analysis dimensions

For every Board or Watch event, test:

- `share`: adoption, switching, retention, competitive intensity, or market expansion
- `access`: eligibility, reimbursement, procurement, distribution, platform, channel, or geography
- `positioning`: evidence, performance, safety, convenience, workflow, brand, service, or price
- `economics`: price, margin, contracting leverage, acquisition cost, lifetime value, or category value
- `timing`: launch, approval, trial, scale-up, response window, or resource sequence

Use only dimensions with a defensible causal mechanism.

## Reasoning pattern

Write implications in this order:

1. Event changes a specific market condition.
2. That condition affects a defined customer, channel, competitor, or decision.
3. The effect creates a positive, negative, mixed, neutral, or uncertain implication for the focal product.
4. State what should happen next and by when or upon what trigger.

## Actions

Board-level actions should be concrete, such as:

- Change or test pricing and contracting
- Accelerate evidence, product, access, supply, or channel work
- Conduct customer-overlap or switching analysis
- Prepare a response narrative or field enablement
- Engage a partner, payer, regulator, standards body, customer, or distributor
- Update scenarios, forecasts, or launch assumptions
- Decide explicitly to take no action and document why

Name a functional owner where possible. Do not prescribe unsupported legal, medical, regulatory, or safety actions; route them to qualified experts.

## Watch triggers

Define observable escalation triggers: filing acceptance, pivotal results, launch date, price publication, national contract, customer migration, policy enactment, manufacturing validation, or financing close.

## Assumptions

Distinguish sourced facts from analytical assumptions. If internal data is needed, identify the exact data gap rather than inventing a quantitative effect.

## Output

Return `ImplicationAssessment` objects matching `references/data-contracts.md`.
