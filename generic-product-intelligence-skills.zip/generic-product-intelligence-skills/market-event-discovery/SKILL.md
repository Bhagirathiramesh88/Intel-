---
name: market-event-discovery
description: Discovers dated market-event candidates for any product across regulatory, product, technical, clinical, commercial, corporate, policy, safety, supply, partner, and substitute domains. Use for current or historical competitive-intelligence scans after a research universe and date range are defined.
license: MIT
compatibility: Requires current web, registry, filing, news, or database access.
metadata:
  category: competitive-intelligence
  role: discovery
---

# Market Event Discovery

## Objective

Find candidate events comprehensively while avoiding premature conclusions.

## Search order

1. Authoritative records: regulators, government databases, courts, patent offices, legislatures, procurement systems, registries, standards bodies, recall and shortage databases.
2. Direct sources: company newsrooms, investor relations, filings, product documentation, pricing pages, release notes, status pages, and partner announcements.
3. Independent sources: peer-reviewed journals, reputable trade press, and major news organizations.
4. Lead-only sources: aggregators, snippets, social posts, and unsourced blogs.

## Event classes

Search only applicable classes:

- Regulatory or standards actions
- Pivotal clinical, technical, performance, safety, or usability results
- Trial, validation, beta, pilot, or pivotal-test starts, stops, or redesigns
- Launches, withdrawals, major releases, and geographic expansions
- Pricing, packaging, reimbursement, formulary, channel, procurement, and major-customer changes
- Supply disruptions, shortages, capacity constraints, recalls, critical incidents, and outages
- M&A, licensing, distribution, co-promotion, manufacturing, financing, IP, and litigation
- Guidelines, legislation, policy, certification, and professional standards

## Discovery rules

- Use short entity-specific queries rather than one large query.
- Include aliases, code names, regional spellings, and mechanism synonyms.
- Capture the underlying event date and article publication date separately.
- Search backward enough to detect whether current coverage restates an older announcement.
- Save direct URLs and exact source titles.
- Record weak leads but do not promote them to facts.
- Deduplicate obvious press-release syndications at discovery time.

## Exclusions

Do not retain routine conferences with no new data, generic forecasts, awards, SEO content, listicles, low-level personnel changes, stock-price stories without an underlying event, or repeated summaries of known events.

## Output

Return `EventCandidate` objects matching `references/data-contracts.md`. Do not assign strategic importance or confidence; those belong to later skills.

## Completion check

For each research-universe group, confirm searches covered applicable event classes and the full date window. Report inaccessible sources and search gaps.
